package com.neubula.onnline.cores;

/**
 * Created by quadri on 16/11/15.
 */
public class PrefConstants {

    public static final String NAME = "name";
    public static final String USER_ID = "user_id";
    public static final String EMAIL = "email";
    public static final String DOWNLOADED_VERSION = "downloaded_version";
    public static final String CURRENT_VERSION = "current_version";
    public static final String SKIP_VERSION = "skip_version";
    public static final String CURRENT_VERSION_FIX = "current_version_fix";
    public static final String API_TOKEN = "API_TOKEN";
    public static final String VERIFY_FORM = "VERIFY_FORM";
}
